<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>edit</title>
</head>
<body>
    <h1>Edit</h1>
</body>
</html><?php /**PATH C:\Users\Dulce Limones\Documents\UTM\Semestre 8\Diseño de aplicaciones web\tarea 5\tarea_5\resources\views/edit.blade.php ENDPATH**/ ?>