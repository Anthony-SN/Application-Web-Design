<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index</title>
</head>
<body>
    <h1>Index</h1>
    <button type="button" onclick="window.location='<?php echo e(url("/create")); ?>'">Add Product</button>
</body>
</html><?php /**PATH C:\Users\Dulce Limones\Documents\UTM\Semestre 8\Diseño de aplicaciones web\tarea 5\tarea_5\resources\views/index.blade.php ENDPATH**/ ?>